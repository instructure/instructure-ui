# Heading


Heading is a component for creating typographic headings.

### Variant

Variant covers almost all use cases for headings on pages. Their name reflects the places they meant to be used. It takes care of the style of the heading

```js
---
type: embed
---
<Alert variant="info">
  <List margin="0 0 general.spaceXl">
    <List.Item>For legacy reasons, each <code>variant</code> has a default <code>level</code> set. This is not the recommended way and will be removed in a later major release. Please always specify the <code>level</code>!</List.Item>
    <List.Item>When <code>variant</code> is set the <code>as</code> prop is ignored</List.Item>
    <List.Item>A11Y GUIDELINE: There can be only one <code>h1</code> tag in a page</List.Item>
    <List.Item>A11Y GUIDELINE: <code>h</code> tags can not skip a level, so for example an <code>h1</code> followed by an <code>h3</code> not allowed</List.Item>
  </List>
</Alert>
```

```js
---
type: example
---
  <div>
    <Heading variant="titlePageDesktop" level="h1"> titlePageDesktop </Heading><br/>
    <Heading variant="titlePageMobile" level="h1"> titlePageMobile </Heading><br/>
    <Heading variant="titleSection" level="h2"> titleSection </Heading><br/>
    <Heading variant="titleCardSection" level="h2"> titleCardSection </Heading><br/>
    <Heading variant="titleModule" level="h2"> titleModule </Heading><br/>
    <Heading variant="titleCardLarge" level="h3"> titleCardLarge </Heading><br/>
    <Heading variant="titleCardRegular" level="h3"> titleCardRegular </Heading><br/>
    <Heading variant="titleCardMini" level="h4"> titleCardMini </Heading><br/>
    <Heading variant="label" level="h5"> label </Heading><br/>
    <Heading variant="labelInline" level="h6"> labelInline </Heading><br/>
  </div>
```

### AI Heading

Use the `aiVariant` prop for headings of AI-related content, such as a Modal or Popover header. Use a standard Heading for all other headings.

`stacked` and `horizontal` show the IgniteAI logo lockup before the heading text:

```js
---
type: example
---
<div style={{display: 'flex', flexDirection: 'column', gap: '24px'}}>
  <Heading aiVariant="stacked" level="h2">Stacked AI heading</Heading>
  <Heading aiVariant="horizontal" level="h3">Horizontal AI heading</Heading>
</div>
```

`iconOnly` shows only the AI icon, and it comes in the same sizes as the standard Heading. Set the size with the `variant` or `level` prop, and the icon scales to match:

```js
---
type: example
---
<div style={{display: 'flex', flexDirection: 'column', gap: '16px'}}>
  <Heading aiVariant="iconOnly" variant="titlePageDesktop">titlePageDesktop</Heading>
  <Heading aiVariant="iconOnly" variant="titlePageMobile">titlePageMobile</Heading>
  <Heading aiVariant="iconOnly" variant="titleSection">titleSection</Heading>
  <Heading aiVariant="iconOnly" variant="titleCardSection">titleCardSection</Heading>
  <Heading aiVariant="iconOnly" variant="titleModule">titleModule</Heading>
  <Heading aiVariant="iconOnly" variant="titleCardLarge">titleCardLarge</Heading>
  <Heading aiVariant="iconOnly" variant="titleCardRegular">titleCardRegular</Heading>
  <Heading aiVariant="iconOnly" variant="titleCardMini">titleCardMini</Heading>
  <Heading aiVariant="iconOnly" variant="label">label</Heading>
</div>
```

For example, in a Modal header:

```js
---
type: example
---
const Example = () => {
  const [open, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={() => setOpen(true)}>Open Modal</Button>
      <Modal
        open={open}
        onDismiss={() => setOpen(false)}
        size="small"
        label="Summarize with AI"
      >
        <Modal.Header>
          <CloseButton
            placement="end"
            offset="small"
            onClick={() => setOpen(false)}
            screenReaderLabel="Close"
          />
          <Heading aiVariant="iconOnly" variant="titleCardLarge">
            Summarize with AI
          </Heading>
        </Modal.Header>
        <Modal.Body>
          <Text>The AI-generated summary goes here.</Text>
        </Modal.Body>
      </Modal>
    </div>
  )
}

render(<Example />)
```

### Heading level

What DOM element is output is determined in the following order:

1. (deprecated) If the variant prop is set, then the value of level prop. If variant is set but level is not, <h1>-<h6> based on the variant prop's value.
2. The value of the `as` prop
3. The value of the `level` prop
4. `<h2>`

The `variant` and `level` props sets its appearance in this order.

```js
---
type: example
---
<div>
  <Heading level="h1" as="h3" margin="0 0 general.spaceSm">This renders as <code>&lt;h3&gt;</code></Heading>
</div>
```

### Heading colors

The default color is `primary`, but it can be set to `secondary`, `primary-on`, `secondary-on` or `inherit` via the `color` prop. Note there is an inverse option available as well: `primary-inverse` or `secondary-inverse` (_see inverse example below_).

```js
---
type: example
---
<div >
  <div style={{color: '#0084D1'}}>
    <Heading color="inherit">I inherit my color via the CSS cascade</Heading>
  </div>
  <Heading color="primary">I am primary color (default)</Heading>
  <Heading color="secondary">I am secondary color</Heading>
  <View background="primary-inverse" as="div">
    <Heading color="primary-inverse">I am primary-inverse color</Heading>
    <Heading color="secondary-inverse">I am secondary-inverse color</Heading>
  </View>
  <View background="alert" as="div">
    <Heading color="primary-on">I am primary-on color</Heading>
    <Heading color="secondary-on">I am secondary-on color</Heading>
  </View>
</div>
```

### Icons

With the `renderIcon` prop, an icon can be rendered before the text.

```js
---
type: example
---
<div>
 <Heading renderIcon={<ShieldUserInstUIIcon/>}>I am heading with icon</Heading>
</div>
```

### Heading borders

The default is no borders. However, using the `border` prop, you can
add either `top` or `bottom` borders to your heading.

```js
---
type: example
---
<div>
  <Heading margin="0 0 general.spaceXl" border="bottom">I have a bottom border</Heading>
  <Heading border="top">I have a top border</Heading>
</div>
```

### Ellipsis text overflow

Use [TruncateText](TruncateText) if you need to constrain your
Heading to a single line (or certain number of lines).

```js
---
type: example
---
<Heading level="h2">
  <TruncateText>{lorem.paragraph()}</TruncateText>
</Heading>
```

### Guidelines

```js
---
type: embed
---
<Guidelines>
  <Figure recommendation="a11y" title="Accessibility">
    <Figure.Item>Each page should always contain one and only one H1</Figure.Item>
    <Figure.Item>Headings should be used in logical order</Figure.Item>
    <Figure.Item>Headings should not be used to format text</Figure.Item>
  </Figure>
</Guidelines>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| Heading | aiVariant | `'stacked' \| 'horizontal' \| 'iconOnly'` | No | - | transforms heading into an `ai` variant |
| Heading | children | `React.ReactNode` | No | `null` | The text content of the Heading |
| Heading | border | `'none' \| 'top' \| 'bottom'` | No | `'none'` | Add a top- or bottom-border to the Heading |
| Heading | color | `\| 'primary' \| 'secondary' \| 'primary-inverse' \| 'secondary-inverse' \| 'inherit' \| 'primary-on' \| 'secondary-on'` | No | `'primary'` | The font color to render |
| Heading | level | `HeadingLevel<'h1' \| 'h2' \| 'h3' \| 'h4' \| 'h5' \| 'h6'> \| 'reset'` | No | - | The level of the heading in the DOM: h1 is largest; h6 is smallest. |
| Heading | as | `AsElementType` | No | - | What DOM element is output is determined in the following order: 1. (deprecated) If `variant` is set, then use the `level` prop, if that's not set use `<h1>`-`<h6>` based on the `variant` prop's value 2. The value of the `as` prop 3. The value of the `level` prop 4. `<h2>` |
| Heading | margin | `Spacing` | No | - | Valid values are `0`, `none`, `auto`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `margin="general.spaceMd auto"`. |
| Heading | elementRef | `(element: Element \| null) => void` | No | - | Provides a ref to the underlying HTML element |
| Heading | renderIcon | `Renderable` | No | - | An icon, or function that returns an icon that gets displayed before the text. |
| Heading | variant | `\| 'titlePageDesktop' \| 'titlePageMobile' \| 'titleSection' \| 'titleCardSection' \| 'titleModule' \| 'titleCardLarge' \| 'titleCardRegular' \| 'titleCardMini' \| 'label' \| 'labelInline'` | No | - | Sets appearance of the heading. Will also set its heading level, if not specified by the `level` prop (deprecated, not recommended!) |

### Usage

Install the package:

```shell
npm install @instructure/ui-heading
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { Heading } from '@instructure/ui-heading/v11_7'
```

