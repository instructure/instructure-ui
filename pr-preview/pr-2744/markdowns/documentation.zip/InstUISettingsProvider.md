# InstUISettingsProvider

@module InstUISettingsProvider
The `<InstUISettingsProvider/>` component provides a way to add global configuration to our app. It can be used to apply and handle themes (for all themeable child components that use the [withStyleNew](withStyleNew) decorator), setting the global text direction, etc.

Note that `<InstUISettingsProvider/>` components can be nested!

Table of Contents:

- [Theme management](/#InstUISettingsProvider/#theme-management)
  - [Applying theme to the application](/#InstUISettingsProvider/#theme-management-applying-theme-to-the-application)
  - [Nesting theme providers](/#InstUISettingsProvider/#theme-management-nesting-theme-providers)
  - [Theme overrides](/#InstUISettingsProvider/#theme-management-theme-overrides)
- [Text direction management](/#InstUISettingsProvider/#text-direction-management)
- [Server side rendering (SSR)](/#server-side-rendering)
- [Properties](/#InstUISettingsProvider/#InstUISettingsProviderProperties)

### Theme management

`<InstUISettingsProvider/>` is a wrapper for the [ThemeProvider](https://emotion.sh/docs/theming#themeprovider-reactcomponenttype) of Emotion library that we use under the hood for theming and applying css styles to our components.

#### Applying theme to the application

The `theme` prop applies the given theme. It handles either a full theme, or an overrides object. Theme properties will fall back to the parent theme, or the default `canvas` theme when they are not set.

To apply a theme to whole app, you need to import `<InstUISettingsProvider/>` and the theme you want to use from `@instructure/ui-themes` (or use your own compatible theme), and wrap your app in the theme provider.

```js
---
  type: code
---
import React from 'react'
import ReactDOM from 'react-dom'

import { InstUISettingsProvider } from '@instructure/emotion'

import { App } from './App'

ReactDOM.render(
  <InstUISettingsProvider>
    <App />
  </InstUISettingsProvider>,
  document.getElementById('app')
)
```

#### Nesting theme providers

```js
---
  type: code
---
<InstUISettingsProvider theme={canvas}>
  <Heading>I should have "canvas" font family.</Heading>

  <InstUISettingsProvider>
    <Heading>I should have "instructure" font family.</Heading>
  </InstUISettingsProvider>
</InstUISettingsProvider>
```

#### Theme overrides

There are multiple ways to override themes in InstUI. You can read about how these work on the dedicated docs pages:

- [Legacy theme overrides](/#legacy-theme-overrides).
- [New theme overrides](/#new-theme-overrides).

### Text direction management

The `dir` prop sets the text direction for its descendants. It wraps its children in a [TextDirectionContext.Provider](/#TextDirectionContext), so that the text direction context can be consumed by child components that have implemented [textDirectionContextConsumer](textDirectionContextConsumer).

If no `dir` prop is supplied, it will fall back to its parent context if it
exists. Otherwise, it queries for and uses the documentElement `dir` attribute and defaults to `ltr` if it is not found.

```js
---
type: example
---

<InstUISettingsProvider dir="ltr">
  <div><Text>LTR text</Text></div>
  <Badge count={105} countUntil={100} margin="small medium 0 0">
    <Button>LTR Badge</Button>
  </Badge>

  <InstUISettingsProvider dir="rtl">
    <View as="div">
      <div><Text>Nested RTL text</Text></div>
      <Badge count={105} countUntil={100} margin="small medium 0 0">
        <Button>Nested RTL Badge</Button>
      </Badge>
    </View>
  </InstUISettingsProvider>

  <div><Text>LTR text</Text></div>
  <div><Text>LTR text</Text></div>
</InstUISettingsProvider>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| InstUISettingsProvider | children | `React.ReactNode` | No | - |  |
| InstUISettingsProvider | theme | `\| BaseThemeOrOverride \| ((theme: BaseTheme) => BaseThemeOrOverride)` | No | `{}` | A full theme or an override object. The override only works for legacy (v11.6 or earlier) themes, for newer ones use the `themeOverride` prop. |
| InstUISettingsProvider | themeOverride | `\| NewThemeOverrideObject \| ((theme: Theme) => NewThemeOverrideObject)` | No | - | An override object for the new theming system. It will be deep merged into the theme. One can override primitives, semantics and individual component's themes, for example: ```js themeOverride={{ semantics: { color: { stroke: { error: 'purple' } } }, primitives: { color: { blue: { blue100: 'yellow' } } }, components: { Alert: { infoBackground: 'brown', infoBorderColor: 'darkblue', borderWidth: '0.5rem' }, Pill: { baseTextColor: 'purple', baseBorderColor: 'purple' } }, sharedTokens: { focusOutline: { width: '0.55rem', infoColor: 'deeppink' } } }} ``` |
| InstUISettingsProvider | instanceCounterMap | `DeterministicIdProviderValue` | No | - | @deprecated the `instanceCounterMap` prop is deprecated. You don't need to supply the `instanceCounterMap` to the component. It handles it internally. A [Map](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Map) which keeps track of specific InstUI components. (generally this is used for deterministic id generation for [SSR](/#server-side-rendering)) |

### Usage

Install the package:

```shell
npm install @instructure/emotion
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { InstUISettingsProvider } from '@instructure/emotion'
```

