# CheckboxGroup


A `<CheckboxGroup/>` is a group of [Checkbox](Checkbox) components that share the same name. You can
set an array `value` for the entire group and it will handle setting the `checked` and `name` props for you.
The Checkbox components can be rendered vertically or horizontally using the `layout` property.

```js
---
type: example
---
<FormFieldGroup description={<ScreenReaderContent>CheckboxGroup examples</ScreenReaderContent>}>
  <CheckboxGroup name="sports"
    onChange={function (value) { console.log(value) }}
    defaultValue={['football', 'volleyball']}
    description="Select your favorite sports"
  >
    <Checkbox label="Football" value="football" />
    <Checkbox label="Basketball" value="basketball" />
    <Checkbox label="Volleyball" value="volleyball" />
    <Checkbox label="Other" value="other" />
  </CheckboxGroup>
  <CheckboxGroup name="sports" size="small"
    layout="columns"
    onChange={function (value) { console.log(value) }}
    defaultValue={['football', 'volleyball']}
    description="Select your favorite sports"
  >
    <Checkbox label="Football" value="football" />
    <Checkbox label="Basketball" value="basketball" />
    <Checkbox label="Volleyball" value="volleyball" />
    <Checkbox label="Other" value="other" />
  </CheckboxGroup>
</FormFieldGroup>
```

The `toggle` variant with `layout` prop set to `inline` and an error message:

```js
---
type: example
---
<CheckboxGroup
  name="sports2"
  layout="inline"
  messages={[
    { text: 'Invalid name', type: 'error' }
  ]}
  onChange={function (value) { console.log(value) }}
  defaultValue={['soccer', 'volleyball']}
  description="I wish to receive score alerts for"
>
  <Checkbox label="Football" value="football" variant="toggle" />
  <Checkbox label="Basketball" value="basketball" variant="toggle" />
  <Checkbox label="Volleyball" value="volleyball" variant="toggle" />
  <Checkbox label="Soccer" value="soccer" variant="toggle" />
</CheckboxGroup>
```

You can set disable/readonly on a group and it works much the same way as a RadioInputGroup.

A `disabled` CheckboxGroup:

```js
---
type: example
---
<CheckboxGroup
  name="sports4"
  onChange={function (value) { console.log(value) }}
  defaultValue={['soccer', 'volleyball']}
  description="I wish to receive score alerts for"
  disabled
>
  <Checkbox label="Football" value="football" variant="toggle" />
  <Checkbox label="Basketball" value="basketball" variant="toggle" />
  <Checkbox label="Volleyball" value="volleyball" variant="toggle" />
  <Checkbox label="Soccer" value="soccer" variant="toggle" />
</CheckboxGroup>
```

### Guidelines

```js
---
type: embed
---
<Guidelines>
  <Figure recommendation="yes" title="Do">
    <Figure.Item>Align to the left side of the label</Figure.Item>
    <Figure.Item>Use when multiple selections are allowed</Figure.Item>
    <Figure.Item>Use to save space from toggles</Figure.Item>
    <Figure.Item>Stack vertically if there is more than two options to select</Figure.Item>
  </Figure>
  <Figure recommendation="no" title="Don't">
    <Figure.Item>Run more than two checkboxes horizontally</Figure.Item>
  </Figure>
</Guidelines>
```

```js
---
type: embed
---
<Guidelines>
  <Figure recommendation="a11y" title="Accessibility">
    <Figure.Item>Ensure CheckboxGroups are labeled correctly so screen readers announce what the group of checkboxes are used for</Figure.Item>
  </Figure>
</Guidelines>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| CheckboxGroup | children | `CheckboxChild[]` | No | `null` |  |
| CheckboxGroup | name | `string` | Yes | - |  |
| CheckboxGroup | description | `React.ReactNode` | Yes | - |  |
| CheckboxGroup | defaultValue | `(string \| number)[]` | No | - |  |
| CheckboxGroup | value | `(string \| number)[]` | No | - |  |
| CheckboxGroup | onChange | `(value: (string \| number)[]) => void` | No | - |  |
| CheckboxGroup | disabled | `boolean` | No | `false` |  |
| CheckboxGroup | readOnly | `boolean` | No | `false` |  |
| CheckboxGroup | messages | `FormMessage[]` | No | - |  |
| CheckboxGroup | size | `'small' \| 'medium' \| 'large'` | No | `'medium'` |  |
| CheckboxGroup | layout | `'stacked' \| 'columns' \| 'inline'` | No | `'stacked'` |  |

### Usage

Install the package:

```shell
npm install @instructure/ui-checkbox
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { CheckboxGroup } from '@instructure/ui-checkbox'
```

