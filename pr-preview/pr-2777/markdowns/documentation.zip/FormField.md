# FormField


This is a helper component that is used by most of the custom form
components. In most cases it shouldn't be used directly.

### Accessibility

`FormField` renders a `<label>` that wraps the label text, and links it to
the form control via its `for` attribute. Make sure that you mind the following:

- The control needs to have the same `id` as the one passed to `FormField` via `labelId`.
  you can also use `aria-labelledby` on your control to read the label.
- Messages aren't part of the control's accessible name. To have screen readers
  announce them, pass a function as `children`. It receives `{ describedBy }`,
  the id of the rendered messages (or `undefined` when none are shown), which
  you add to the control's `aria-describedby`.

```js
---
type: code
---
<FormField id="email" label="Email" messages={messages}>
  {({ describedBy }) => (
    <input id="email" type="email" aria-describedby={describedBy} />
  )}
</FormField>
```

Clicking non-interactive content around the control (e.g. icons or padding)
focuses and clicks the control, like clicking the label does.

```js
---
type: example
---
<div>
  <FormField id="_foo121" label="Stacked layout" width="400px" layout="stacked"
             messages={[{type:'success', text: 'This is a success message'}, {type:'error', text: 'An error message. It will wrap if the text is longer than the width of the container.'}]}>
    <TextInput id="_foo121"/>
  </FormField>
  <hr/>
  <FormField id="_foo122" label="Stacked layout (inline=true)" width="400px" layout="stacked" inline
             messages={[{type:'success', text: 'This is a success message'}, {type:'error', text: 'An error message. It will wrap if the text is longer than the width of the container.'}]}>
    <TextInput id="_foo122"/>
  </FormField>
  <hr/>
  <FormField id="_foo123" label="Inline layout" width="400px" layout="inline"
             messages={[{type:'success', text: 'success!'}, {type:'error', text: 'An error message. It will wrap if the text is longer than the width of the container.'}]}>
    <TextInput id="_foo123"/>
  </FormField>
  <hr/>
  <FormField id="_foo124" label="Inline layout (inline=true)" width="400px" layout="inline" inline
             messages={[{type:'success', text: 'success!'}, {type:'error', text: 'An error message. It will wrap if the text is longer than the width of the container.'}]}>
    <TextInput id="_foo124"/>
  </FormField>
  <hr/>
  <FormField id="_foo125" label={<ScreenReaderContent>hidden text</ScreenReaderContent>} width="400px" layout="stacked">
    <TextInput id="_foo125" />
  </FormField>
  <hr/>
</div>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| FormField | label | `React.ReactNode` | Yes | - |  |
| FormField | id | `string` | Yes | - | the id of the input (to link it to its label for a11y). Applied as the `for` HTML prop on the label. |
| FormField | messages | `FormMessage[]` | No | - | Array of objects with shape: `{ text: React.ReactNode, type: One of: ['newError', 'error', 'hint', 'success', 'screenreader-only'] }` |
| FormField | messagesId | `string` | No | - | id for the form field messages |
| FormField | labelId | `string` | No | - | `id` for the label/legend element. Useful when the control is not a [labelable](https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Content_categories#labelable) element (e.g. a custom widget), and needs to reference the label via `aria-labelledby`. |
| FormField | children | `\| React.ReactNode \| ((params: FormFieldLayoutChildrenParams) => React.ReactNode)` | No | - | The form control. Can be a function that receives `{ describedBy }`, so the control can reference the messages via `aria-describedby`. |
| FormField | inline | `boolean` | No | `false` |  |
| FormField | layout | `'stacked' \| 'inline'` | No | `'stacked'` |  |
| FormField | labelAlign | `'start' \| 'end'` | No | `'end'` |  |
| FormField | vAlign | `'top' \| 'middle' \| 'bottom'` | No | `'middle'` |  |
| FormField | width | `string` | No | - |  |
| FormField | inputContainerRef | `(element: HTMLSpanElement \| null) => void` | No | - |  |
| FormField | elementRef | `(element: Element \| null) => void` | No | - | provides a reference to the underlying html root element |
| FormField | isRequired | `boolean` | No | - | If `true`, displays an asterisk after the label to indicate the field is required |
| FormField | margin | `Spacing` | No | - | Valid values are `0`, `none`, `auto`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `margin="general.spaceMd auto"`. |
| FormField | disabled | `boolean` | No | - | Whether the field is disabled. When true, error and success messages will be hidden. |
| FormField | readOnly | `boolean` | No | - | Whether the field is read-only. When true, error and success messages will be hidden. |
| FormField.FormFieldLabel | children | `React.ReactNode` | Yes | - |  |
| FormField.FormFieldLabel | as | `AsElementType` | No | `'span'` |  |
| FormField.FormFieldLayout | label | `React.ReactNode` | Yes | - | The label text. Will be appended by a `*` if this field is required. |
| FormField.FormFieldLayout | id | `string` | Yes | - | The id of the form control (=the child of this component). It's applied as the [for](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Attributes/for) attribute of the label, so the control needs to have the same `id`. Not used when rendering as a `fieldset` (group) |
| FormField.FormFieldLayout | as | `AsElementType` | No | - | The element type to render as, `div` be default. Also determines how the `label` will be rendered: If its value is `fieldset` (for form groups), it be rendered in a [legend](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/legend), for all other cases it will be in a [label](https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/label). |
| FormField.FormFieldLayout | messages | `FormMessage[]` | No | - | Array of objects with shape: `{ text: React.ReactNode, type: One of: ['newError', 'error', 'hint', 'success', 'screenreader-only'] }` |
| FormField.FormFieldLayout | messagesId | `string` | No | - | id for the form field messages |
| FormField.FormFieldLayout | labelId | `string` | No | - | `id` for the label/legend element. Useful when the control is not a [labelable](https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Content_categories#labelable) element (e.g. a custom widget), and needs to reference the label via `aria-labelledby={labelId}`. |
| FormField.FormFieldLayout | children | `\| React.ReactNode \| ((params: FormFieldLayoutChildrenParams) => React.ReactNode)` | No | - | The form control(s). Can be a function that receives `{ describedBy }`, so the control can reference the messages via `aria-describedby`. |
| FormField.FormFieldLayout | inline | `boolean` | No | - | If `true` use an inline layout -- content will flow on the left/right side of this component |
| FormField.FormFieldLayout | layout | `'stacked' \| 'inline'` | No | - | In `stacked` mode the container is below the label, in `inline` mode the container is to the right/left (depending on text direction) |
| FormField.FormFieldLayout | labelAlign | `'start' \| 'end'` | No | - | The horizontal alignment of the label. Only works in `inline` layout |
| FormField.FormFieldLayout | vAlign | `'top' \| 'middle' \| 'bottom'` | No | - | The vertical alignment of the label and the controls. "top" by default |
| FormField.FormFieldLayout | width | `string` | No | - |  |
| FormField.FormFieldLayout | inputContainerRef | `(element: HTMLElement \| null) => void` | No | - | Provides a reference to the container that holds the input element @param element The element that holds the input control as its children |
| FormField.FormFieldLayout | elementRef | `(element: Element \| null) => void` | No | - | provides a reference to the underlying html root element |
| FormField.FormFieldLayout | isGroup | `boolean` | No | - |  |
| FormField.FormFieldLayout | isRequired | `boolean` | No | - | If `true`, displays an asterisk after the label to indicate the field is required |
| FormField.FormFieldLayout | margin | `Spacing` | No | - | Valid values are `0`, `none`, `auto`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `margin="general.spaceMd auto"`. |
| FormField.FormFieldLayout | disabled | `boolean` | No | - | Whether the field is disabled. When true, error and success messages will be hidden. |
| FormField.FormFieldLayout | readOnly | `boolean` | No | - | Whether the field is read-only. When true, error and success messages will be hidden. |
| FormField.FormFieldMessage | variant | `\| 'newError' \| 'error' \| 'hint' \| 'success' \| 'screenreader-only'` | No | `'hint'` |  |
| FormField.FormFieldMessage | children | `React.ReactNode` | No | - |  |
| FormField.FormFieldMessages | messages | `FormMessage[]` | No | - | Array of objects with shape: `{ text: React.ReactNode, type: One of: ['newError', 'error', 'hint', 'success', 'screenreader-only'] }` |
| FormField.FormFieldMessages | gridArea | `string` | No | - | Specifies the size and location if inside a CSS grid, see https://developer.mozilla.org/en-US/docs/Web/CSS/grid-area |

### Usage

Install the package:

```shell
npm install @instructure/ui-form-field
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { FormField } from '@instructure/ui-form-field/v11_7'
```

